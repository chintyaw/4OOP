package Cards;

public class Wildcard extends Card{
    public Wildcard()
    {
        super();
    }

    public String toString()
    {
        return "Wildcard";
    }
}
