package Help;

public interface HelpInterface {
    public static void KetentuanPermainan(){}
    public static void GameCommand(){}
    public static void JenisKartu(){}
    public static void KetentuanDiscard(){}
}