package Cards;

public class DrawFour extends Card{
    public DrawFour()
    {
        super();
    }

    public String toString()
    {
        return "Draw 4";
    }
}
